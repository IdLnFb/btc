#!/bin/bash

ADDRESS=${1}
VALUE=${2-10}
FEE_RATE=${3-1}

if [ -z "$ADDRESS" ]
then
    echo 'Missing address'
    exit 1
fi

docker exec -it nodes-bitcoin-local bitcoin-cli -named -datadir=1 sendtoaddress address=$ADDRESS amount=$VALUE fee_rate=$FEE_RATE
