#!/bin/bash

DATA_DIR=$1
WALLET_NAME=$2
DISABLE_PRIVATE_KEYS=${3-true}

if [ -z "${DATA_DIR}" ]; then    
    exit 1
fi

if [ -z "${WALLET_NAME}" ]; then    
    exit 1
fi

bitcoin-cli -named -datadir=$DATA_DIR getwalletinfo

if [ $? -ne 0 ]; then
    bitcoin-cli -named -datadir=$DATA_DIR createwallet wallet_name=$WALLET_NAME disable_private_keys=$DISABLE_PRIVATE_KEYS load_on_startup=true
fi

