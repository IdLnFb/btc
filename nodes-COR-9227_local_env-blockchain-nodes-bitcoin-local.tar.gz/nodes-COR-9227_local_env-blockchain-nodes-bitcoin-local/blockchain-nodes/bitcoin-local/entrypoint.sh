#!/bin/bash

echo 'copying config...'
cp ./configs/1/bitcoin.conf ./1/
cp ./configs/2/bitcoin.conf ./2/

echo 'starting...'
make start

echo 'generating blocks...'
while true; do bitcoin-cli -datadir=1 -generate 1; sleep 5; done
