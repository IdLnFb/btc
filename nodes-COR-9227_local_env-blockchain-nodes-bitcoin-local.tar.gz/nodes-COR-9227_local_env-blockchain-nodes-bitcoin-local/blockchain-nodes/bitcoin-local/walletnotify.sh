#!/bin/bash

TXID=$1

wget http://nodes-api:8000/v1.1/btc_test/txnotify?tx=$TXID --quiet -O /dev/null
